#include <stdlib.h>
#include <stdio.h>

int
main(int argc, char *argv[])
{
	int x = 0;

	for (x = 0; x < 10; x++) {
		printf("x es %d\n", x);
	}
	exit(EXIT_SUCCESS);
}
