#include <stdlib.h>
#include <stdio.h>
#include <stdio.h>

int
main(int argc, char *argv[])
{
	printf("hola mundo");
	exit(EXIT_SUCCESS);
}
