#include <stdlib.h>
#include <stdio.h>

int x;

int
main(int argc, char *argv[])
{
	int x = 1;

	printf("El valor de x es: %d\n", x);
	exit(EXIT_SUCCESS);
}
