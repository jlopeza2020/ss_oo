Este código forma parte del Libro Fundamentos de sistemas operativos: una aproximación práctica usando Linux que puedes encontrar en:

https://github.com/honecomp/honecomp.github.io/raw/main/books/librossoo.pdf

En el libro se describen los programas. 

Este código se distribuye bajo licencia GPLv3. Puedes encontrarla en https://www.gnu.org/licenses/gpl-3.0.en.html


